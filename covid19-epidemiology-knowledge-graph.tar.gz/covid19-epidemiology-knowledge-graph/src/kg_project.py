
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

print("Environment Ready ✅")

# Load datasets
lives_in = pd.read_csv("lives_in.csv")
shows_symptom = pd.read_csv("shows_symptom.csv")
infected_at = pd.read_csv("infected_at.csv")
attended_event = pd.read_csv("attended_event.csv")
print("Datasets Loaded ✅")
print("Lives_in shape:", lives_in.shape)
print("Shows_symptom shape:", shows_symptom.shape)

# -------------------------
# Create Knowledge Graph
# -------------------------

G = nx.DiGraph()

# Add lives_in edges
for _, row in lives_in.iterrows():
    G.add_node(row['Patient'], type='Patient')
    G.add_node(row['City'], type='City')
    G.add_edge(row['Patient'], row['City'], relation='lives_in')

# Add shows_symptom edges
for _, row in shows_symptom.iterrows():
    G.add_node(row['Symptom'], type='Symptom')
    G.add_edge(row['Patient'], row['Symptom'], relation='shows_symptom')

# Add infected_at edges
for _, row in infected_at.iterrows():
    G.add_node(row['Event'], type='Event')
    G.add_edge(row['Patient'], row['Event'], relation='infected_at')

# Add attended_event edges
for _, row in attended_event.iterrows():
    G.add_edge(row['Patient'], row['Event'], relation='attended_event')

print("Knowledge Graph Created ✅")
print("Total Nodes:", G.number_of_nodes())
print("Total Edges:", G.number_of_edges())

# -------------------------
# Visualize Small Subgraph
# -------------------------

# Take first 15 patients + their related cities
sub_nodes = list(lives_in['Patient'][:15]) + list(lives_in['City'][:5])

# Include their symptoms and events
for patient in lives_in['Patient'][:15]:
    sub_nodes += list(shows_symptom[shows_symptom['Patient'] == patient]['Symptom'])
    sub_nodes += list(infected_at[infected_at['Patient'] == patient]['Event'])
    sub_nodes += list(attended_event[attended_event['Patient'] == patient]['Event'])

# Create subgraph
subG = G.subgraph(sub_nodes)

# Draw graph
pos = nx.spring_layout(subG, seed=42)  # positions for all nodes
node_colors = []
for node in subG.nodes():
    if G.nodes[node]['type'] == 'Patient':
        node_colors.append('lightblue')
    elif G.nodes[node]['type'] == 'City':
        node_colors.append('lightgreen')
    elif G.nodes[node]['type'] == 'Symptom':
        node_colors.append('salmon')
    else:
        node_colors.append('orange')

nx.draw(subG, pos, with_labels=True, node_color=node_colors, node_size=1200, font_size=8)
edge_labels = nx.get_edge_attributes(subG, 'relation')
nx.draw_networkx_edge_labels(subG, pos, edge_labels=edge_labels, font_size=7)
plt.title("COVID-19 Knowledge Graph (Small Subgraph)")
plt.show()
